package com.tapmaster.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var bindText: TextView
    private lateinit var nameEt: EditText
    private lateinit var cpsBar: SeekBar
    private lateinit var delayEt: EditText
    private lateinit var pressEt: EditText
    private lateinit var swipeEt: EditText
    private lateinit var loopCb: CheckBox
    private lateinit var repeatEt: EditText
    private lateinit var holdCb: CheckBox
    private lateinit var editCb: CheckBox
    private lateinit var hideCb: CheckBox
    private lateinit var autoHideCb: CheckBox
    private lateinit var volCb: CheckBox
    private lateinit var autoEt: EditText
    private lateinit var sizeBar: SeekBar
    private lateinit var alphaBar: SeekBar
    private lateinit var tapBar: SeekBar
    private lateinit var jitBar: SeekBar
    private lateinit var rndBar: SeekBar
    private lateinit var presetSp: Spinner
    private lateinit var presetEt: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.load(this)
        buildUi()
        syncUi()
        refreshPresets()
    }

    override fun onResume() {
        super.onResume()
        holdCb.isChecked = Store.mode == "hold"
        editCb.isChecked = Store.edit
        autoHideCb.isChecked = Store.autoHide
        volCb.isChecked = Store.volStop
        updateStatus()
    }

    private fun LinearLayout.label(t: String) {
        addView(TextView(this@MainActivity).apply { text = t; setPadding(0, dp(14), 0, 0) })
    }

    private fun LinearLayout.button(t: String, cb: () -> Unit) {
        addView(Button(this@MainActivity).apply { text = t; setOnClickListener { cb() } })
    }

    private fun LinearLayout.seek(
        title: String, lo: Int, hi: Int, cur: Int, unit: String, onChange: (Int) -> Unit
    ): SeekBar {
        val tv = TextView(this@MainActivity).apply {
            text = "$title: $cur$unit"
            setPadding(0, dp(14), 0, 0)
        }
        addView(tv)
        val sb = SeekBar(this@MainActivity).apply {
            max = hi - lo
            progress = cur - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    tv.text = "$title: ${p + lo}$unit"
                    onChange(p + lo)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        addView(sb)
        return sb
    }

    private fun num(e: EditText, d: Int): Int = e.text.toString().toIntOrNull() ?: d

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(40))
        }
        status = TextView(this)
        root.addView(status)
        root.button("Accessibility settings kholo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        root.button("Madad: kaise use kare?") { showHelp() }

        // ================= Naya button =================
        root.label("=== Naya button banao ===")
        root.label("Button ka naam (A-Z / 0-9, max 3). Khali = apne aap")
        nameEt = EditText(this).apply { filters = arrayOf(InputFilter.LengthFilter(3)) }
        root.addView(nameEt)
        cpsBar = root.seek("Tap per second (Single button)", 1, 10, 5, "") {}
        root.button("+ Single tap button (laal)") { addBtn("single", 0, 0) }

        root.label("Sequence: har step ke baad ruk (ms)")
        delayEt = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("100")
        }
        root.addView(delayEt)
        root.label("Long press step ka time (ms)")
        pressEt = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("600")
        }
        root.addView(pressEt)
        root.label("Swipe step ka time (ms)")
        swipeEt = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("300")
        }
        root.addView(swipeEt)

        root.button("+ Sequence step: Tap (neela)") {
            addBtn("seq", num(delayEt, 100), 0)
        }
        root.button("+ Sequence step: Long press (neela)") {
            addBtn("seq", num(delayEt, 100), num(pressEt, 600).coerceAtLeast(50))
        }
        root.button("+ Sequence step: Swipe (baingani)") {
            addBtn("swipe", num(delayEt, 100), num(swipeEt, 300).coerceAtLeast(50))
        }
        root.button("+ Main button (hara, sequence chalata hai)") { addBtn("main", 0, 0) }
        root.button("Last button hatao") { removeLast() }

        // ================= Sequence =================
        root.label("=== Sequence settings ===")
        loopCb = CheckBox(this).apply { text = "Loop ON (sequence baar-baar)" }
        root.addView(loopCb)
        root.label("Kitni baar repeat (0 = jab tak chale)")
        repeatEt = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        root.addView(repeatEt)

        // ================= Chalane ka tareeka =================
        root.label("=== Chalane ka tareeka ===")
        holdCb = CheckBox(this).apply {
            text = "Hold mode (hold = chale, chhodo = ruke). Phone me na chale to app khud Toggle par aa jayegi (ek tap start, dobara tap stop)"
            setOnCheckedChangeListener { _, on -> Store.mode = if (on) "hold" else "toggle" }
        }
        root.addView(holdCb)
        root.label("Auto-stop timer (second, 0 = band)")
        autoEt = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        root.addView(autoEt)
        volCb = CheckBox(this).apply {
            text = "Volume Down = emergency stop (sirf tab jab tap chal raha ho)"
            setOnCheckedChangeListener { _, on ->
                Store.volStop = on
                Store.saveGlobals(this@MainActivity)
            }
        }
        root.addView(volCb)

        // ================= Natural tap =================
        root.label("=== Natural tap (optional) ===")
        tapBar = root.seek("Ek tap kitni der dabe", 10, 200, Store.tapMs, " ms") { Store.tapMs = it }
        jitBar = root.seek("Tap jagah ka random hilna", 0, 30, Store.jitter, " px") { Store.jitter = it }
        rndBar = root.seek("Delay me random badlav", 0, 50, Store.randPct, " %") { Store.randPct = it }

        // ================= Look =================
        root.label("=== Gole ka look ===")
        sizeBar = root.seek("Gole ka size", 80, 240, Store.size, " px") { Store.size = it }
        alphaBar = root.seek("Gole ki dikhawat (opacity)", 30, 100, Store.alphaPct, " %") { Store.alphaPct = it }
        root.label("(Size ya opacity badalne ke baad neeche Apply dabao)")

        editCb = CheckBox(this).apply {
            text = "Edit mode (ON = gole move karo, OFF = chalao). Screen ka grey bubble bhi yahi badalta hai"
            isChecked = Store.edit
            setOnCheckedChangeListener { _, on ->
                Store.edit = on
                ClickerService.instance?.refreshMode()
            }
        }
        root.addView(editCb)
        hideCb = CheckBox(this).apply {
            text = "Gole chhupao (settings na bigde)"
            setOnCheckedChangeListener { _, on ->
                Store.hidden = on
                ClickerService.instance?.refreshMode()
            }
        }
        root.addView(hideCb)

        root.button("Apply / Buttons dikhao") { pushConfig() }
        root.button("Sab buttons hatao") {
            Store.buttons.clear()
            Store.seq.clear()
            Store.nextId = 1
            pushConfig()
        }
        root.button("Tap counter zero karo") {
            Store.tapCount = 0L
            updateStatus()
        }

        // ================= Presets =================
        root.label("=== Presets ===")
        presetSp = Spinner(this)
        root.addView(presetSp)
        presetEt = EditText(this).apply { hint = "Preset ka naam" }
        root.addView(presetEt)
        root.button("Save preset") {
            val n = presetEt.text.toString().trim()
            if (n.isNotEmpty()) {
                syncOpts()
                Store.savePreset(this, n)
                refreshPresets()
                toast("Saved: $n")
            }
        }
        root.button("Load preset") {
            val n = selectedPreset()
            if (n != null && Store.loadPreset(this, n)) {
                syncUi()
                pushConfig()
            }
        }
        root.button("Delete preset") {
            val n = selectedPreset()
            if (n != null) {
                Store.deletePreset(this, n)
                refreshPresets()
            }
        }
        root.button("Preset Copy karo (backup / dost ko bhejo)") {
            syncOpts()
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("preset", Store.toJson().toString()))
            toast("Copy ho gaya. Kahin bhi paste kar sakte ho")
        }
        root.button("Preset Paste karo (import)") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
            try {
                val o = JSONObject(t)
                o.getJSONArray("buttons")
                o.getJSONArray("seq")
                Store.fromJson(o)
                syncUi()
                pushConfig()
            } catch (e: Exception) {
                toast("Clipboard me sahi preset nahi mila")
            }
        }

        // ================= Game se auto preset =================
        root.label("=== Game ke hisaab se auto preset ===")
        bindText = TextView(this)
        root.addView(bindText)
        root.button("Last khele hue app ko selected preset se jodo") {
            val n = selectedPreset()
            val p = Store.lastPkg
            if (n == null) {
                toast("Pehle upar dropdown se preset chuno")
            } else if (p.isEmpty()) {
                toast("Pehle game kholo, phir TapMaster me wapas aao")
            } else {
                Store.bindings[p] = n
                Store.saveGlobals(this)
                updateStatus()
                toast("Jud gaya: $p -> $n")
            }
        }
        root.button("Last app ka binding hatao") {
            Store.bindings.remove(Store.lastPkg)
            Store.saveGlobals(this)
            updateStatus()
        }
        root.button("Sab bindings hatao") {
            Store.bindings.clear()
            Store.saveGlobals(this)
            updateStatus()
        }
        autoHideCb = CheckBox(this).apply {
            text = "Jode hue game ke alawa doosre apps me gole chhupa do"
            setOnCheckedChangeListener { _, on ->
                Store.autoHide = on
                Store.saveGlobals(this@MainActivity)
            }
        }
        root.addView(autoHideCb)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun showHelp() {
        val msg = "1) Accessibility me TapMaster ON karo.\n\n" +
                "2) Single (laal): saath me narangi '+' dot aata hai. Dot ko game ke fire button par rakho, laal gole ko apne angoothe ke paas.\n\n" +
                "3) Sequence: Tap, Long press ya Swipe steps jis order me banaoge usi order me chalenge. Neele gole seedha game ke button par rakho. Swipe me baingani gola shuruat aur '>' dot ant hai.\n\n" +
                "4) Main (hara) gola sequence chalata hai.\n\n" +
                "5) Edit mode OFF karo (ya grey bubble dabao) aur game kholo.\n\n" +
                "6) Hold mode: gola hold karo to chale, chhodo to ruke. Agar phone me ye nahi chalta to app Toggle par aa jati hai: ek tap = start, dobara tap = stop.\n\n" +
                "7) Rokne ke 3 tareeke: gola dobara tap, grey STOP bubble, ya Volume Down.\n\n" +
                "8) Game ke hisaab se auto preset: game kholo, wapas aao, preset chuno aur 'Last khele hue app ko jodo' dabao."
        AlertDialog.Builder(this)
            .setTitle("TapMaster madad")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    // Store ki values ko screen ke controls me bharo
    private fun syncUi() {
        loopCb.isChecked = Store.loop
        repeatEt.setText(Store.repeat.toString())
        autoEt.setText(Store.autoStopSec.toString())
        holdCb.isChecked = Store.mode == "hold"
        sizeBar.progress = Store.size - 80
        alphaBar.progress = Store.alphaPct - 30
        tapBar.progress = Store.tapMs - 10
        jitBar.progress = Store.jitter
        rndBar.progress = Store.randPct
    }

    // Screen ke controls ki values Store me daalo
    private fun syncOpts() {
        Store.loop = loopCb.isChecked
        Store.repeat = num(repeatEt, 0)
        Store.autoStopSec = num(autoEt, 0)
        Store.mode = if (holdCb.isChecked) "hold" else "toggle"
    }

    private fun addBtn(type: String, delay: Int, hold: Int) {
        val dm = resources.displayMetrics
        val cx = dm.widthPixels * 0.5f
        val cy = dm.heightPixels * 0.25f + (Store.buttons.size % 6) * 170
        val id = Store.nextId++
        val n = Store.seq.size + 1
        val raw = nameEt.text.toString().trim().uppercase().filter { it in 'A'..'Z' || it in '0'..'9' }
        val fallback = when (type) {
            "seq" -> if (hold > 0) "${n}L" else "$n"
            "swipe" -> "${n}S"
            "main" -> "GO"
            else -> id.toString()
        }
        val label = if (raw.isEmpty()) fallback else raw.take(3)
        val hasTarget = type == "single" || type == "swipe"
        Store.buttons[id] = Btn(
            id, type, label, cx, cy,
            if (hasTarget) cx + 260 else cx, cy,
            (cpsBar.progress + 1).coerceIn(1, Store.MAX_CPS), delay, hold
        )
        if (type == "seq" || type == "swipe") Store.seq.add(id)
        nameEt.setText("")
        pushConfig()
    }

    private fun removeLast() {
        val last = Store.buttons.keys.lastOrNull() ?: return
        Store.buttons.remove(last)
        Store.seq.remove(last)
        pushConfig()
    }

    private fun pushConfig() {
        syncOpts()
        Store.save(this)
        val s = ClickerService.instance
        if (s == null) toast("Pehle Accessibility me TapMaster ON karo") else s.render()
        updateStatus()
    }

    private fun updateStatus() {
        val acc = if (ClickerService.instance != null)
            "Accessibility ON"
        else
            "Accessibility OFF. Settings > Accessibility > Installed apps > TapMaster > ON karo"
        status.text = acc + "\nButtons: ${Store.buttons.size}    Taps: ${Store.tapCount}"

        val list = if (Store.bindings.isEmpty()) "(koi nahi)"
        else Store.bindings.entries.joinToString("\n") { e -> e.key + " -> " + e.value }
        val last = if (Store.lastPkg.isEmpty()) "(abhi tak koi game nahi dekha)" else Store.lastPkg
        bindText.text = "Jude hue games:\n" + list + "\n\nLast dekha hua app:\n" + last
    }

    private fun refreshPresets() {
        presetSp.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, Store.presetNames(this)
        )
    }

    private fun selectedPreset(): String? = presetSp.selectedItem as? String

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
