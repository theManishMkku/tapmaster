package com.tapmaster.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

// type: "single" (laal), "seq" (neela tap/long press step), "swipe" (baingani step), "main" (hara)
data class Btn(
    val id: Int, val type: String, val label: String,
    var x: Float, var y: Float, var tx: Float, var ty: Float,
    val cps: Int, val delayMs: Int, val holdMs: Int
)

object Store {
    const val MAX_CPS = 10

    // ---- preset me jaane wali cheezein ----
    val buttons = LinkedHashMap<Int, Btn>()
    var seq = mutableListOf<Int>()
    var loop = true
    var repeat = 0
    var mode = "hold"          // "hold" ya "toggle"
    var size = 140
    var alphaPct = 75
    var jitter = 0
    var randPct = 0
    var autoStopSec = 0
    var tapMs = 40
    var ctlX = -1
    var ctlY = -1

    // ---- sirf abhi ki halat (save nahi hoti) ----
    var edit = true
    var hidden = false
    var nextId = 1
    var tapCount = 0L
    var lastPkg = ""
    var activePkg = ""

    // ---- global settings (presets se alag) ----
    var autoHide = false
    var volStop = true
    val bindings = HashMap<String, String>()

    fun toJson(): JSONObject {
        val arr = JSONArray()
        for (b in buttons.values) {
            arr.put(
                JSONObject()
                    .put("id", b.id).put("type", b.type).put("label", b.label)
                    .put("x", b.x.toDouble()).put("y", b.y.toDouble())
                    .put("tx", b.tx.toDouble()).put("ty", b.ty.toDouble())
                    .put("cps", b.cps).put("delay", b.delayMs).put("hold", b.holdMs)
            )
        }
        return JSONObject().put("buttons", arr).put("seq", JSONArray(seq))
            .put("loop", loop).put("repeat", repeat)
            .put("mode", mode).put("size", size).put("alpha", alphaPct)
            .put("jitter", jitter).put("randPct", randPct)
            .put("autoStop", autoStopSec).put("tapMs", tapMs)
            .put("cx", ctlX).put("cy", ctlY)
    }

    fun fromJson(o: JSONObject) {
        buttons.clear()
        seq = mutableListOf()
        nextId = 1
        val arr = o.getJSONArray("buttons")
        for (i in 0 until arr.length()) {
            val j = arr.getJSONObject(i)
            val b = Btn(
                j.getInt("id"), j.getString("type"), j.getString("label"),
                j.getDouble("x").toFloat(), j.getDouble("y").toFloat(),
                j.getDouble("tx").toFloat(), j.getDouble("ty").toFloat(),
                j.getInt("cps").coerceIn(1, MAX_CPS), j.getInt("delay"),
                j.optInt("hold", 0)
            )
            buttons[b.id] = b
            if (b.id >= nextId) nextId = b.id + 1
        }
        val s = o.getJSONArray("seq")
        for (i in 0 until s.length()) seq.add(s.getInt(i))
        loop = o.optBoolean("loop", true)
        repeat = o.optInt("repeat", 0)
        mode = o.optString("mode", "hold")
        size = o.optInt("size", 140).coerceIn(80, 240)
        alphaPct = o.optInt("alpha", 75).coerceIn(30, 100)
        jitter = o.optInt("jitter", 0).coerceIn(0, 30)
        randPct = o.optInt("randPct", 0).coerceIn(0, 50)
        autoStopSec = o.optInt("autoStop", 0).coerceAtLeast(0)
        tapMs = o.optInt("tapMs", 40).coerceIn(10, 200)
        ctlX = o.optInt("cx", -1)
        ctlY = o.optInt("cy", -1)
    }

    private fun prefs(c: Context) = c.getSharedPreferences("tapmaster", Context.MODE_PRIVATE)

    fun save(c: Context) {
        prefs(c).edit().putString("current", toJson().toString()).apply()
    }

    fun load(c: Context) {
        loadGlobals(c)
        val s = prefs(c).getString("current", null) ?: return
        try { fromJson(JSONObject(s)) } catch (e: Exception) { }
    }

    fun saveGlobals(c: Context) {
        val b = JSONObject()
        for ((k, v) in bindings) b.put(k, v)
        prefs(c).edit()
            .putBoolean("autoHide", autoHide)
            .putBoolean("volStop", volStop)
            .putString("bindings", b.toString())
            .apply()
    }

    private fun loadGlobals(c: Context) {
        val p = prefs(c)
        autoHide = p.getBoolean("autoHide", false)
        volStop = p.getBoolean("volStop", true)
        bindings.clear()
        try {
            val o = JSONObject(p.getString("bindings", "{}") ?: "{}")
            val ks = o.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                bindings[k] = o.getString(k)
            }
        } catch (e: Exception) { }
    }

    private fun presets(c: Context): JSONObject =
        try { JSONObject(prefs(c).getString("presets", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    fun presetNames(c: Context): List<String> = presets(c).keys().asSequence().toList()

    fun savePreset(c: Context, name: String) {
        val o = presets(c)
        o.put(name, toJson())
        prefs(c).edit().putString("presets", o.toString()).apply()
    }

    fun loadPreset(c: Context, name: String): Boolean {
        val p = presets(c).optJSONObject(name) ?: return false
        fromJson(p)
        save(c)
        return true
    }

    fun deletePreset(c: Context, name: String) {
        val o = presets(c)
        o.remove(name)
        prefs(c).edit().putString("presets", o.toString()).apply()
    }
}
