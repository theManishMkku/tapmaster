package com.tapmaster.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class ClickerService : AccessibilityService() {

    companion object {
        @Volatile var instance: ClickerService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val btnViews = HashMap<Int, View>()
    private val tgtViews = HashMap<Int, View>()
    private var ctlView: TextView? = null
    private val rnd = java.util.Random()
    private var runToken = 0
    private var runningId = -1
    private var pressAt = 0L

    private val wm: WindowManager get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager

    // SPLIT_TOUCH + NOT_TOUCH_MODAL: gole par ungli ho tab bhi baaki screen par doosri ungli chalti hai
    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_SPLIT_TOUCH

    override fun onServiceConnected() {
        instance = this
        Store.load(this)
        Store.edit = true
        Store.hidden = false
        Store.activePkg = ""
        render()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopRun()
        removeAll()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    // ---------- Game ke hisaab se auto preset ----------
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (pkg == "com.android.systemui" || pkg.contains("inputmethod") || pkg.contains("keyboard")) return
        Store.lastPkg = pkg
        val preset = Store.bindings[pkg]
        if (preset != null) {
            val wasHidden = Store.hidden
            Store.hidden = false
            if (Store.activePkg != pkg) {
                Store.activePkg = pkg
                if (Store.loadPreset(this, preset)) {
                    Store.edit = false
                }
                render()
            } else if (wasHidden) {
                refreshMode()
            }
        } else if (Store.autoHide && !Store.hidden) {
            Store.activePkg = ""
            Store.hidden = true
            refreshMode()
        }
    }

    // ---------- Volume Down = emergency stop ----------
    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null) return false
        if (Store.volStop && runningId != -1 &&
            event.action == KeyEvent.ACTION_DOWN &&
            event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
        ) {
            stopRun()
            return true
        }
        return false
    }

    // ---------- Gestures ----------
    private fun gesture(p: Path, dur: Long) {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, dur.coerceAtLeast(1L)))
            .build()
        dispatchGesture(g, null, null)
        Store.tapCount++
    }

    fun tap(x: Float, y: Float, dur: Long = Store.tapMs.toLong()) {
        val p = Path().apply { moveTo(x, y) }
        gesture(p, dur)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        gesture(p, dur.coerceAtLeast(50L))
    }

    private fun jit(v: Float): Float =
        if (Store.jitter > 0) v + (rnd.nextFloat() * 2f - 1f) * Store.jitter else v

    private fun rdelay(ms: Long): Long {
        val p = Store.randPct
        if (p <= 0) return ms
        val f = 1f + (rnd.nextFloat() * 2f - 1f) * p / 100f
        return (ms * f).toLong().coerceAtLeast(20L)
    }

    // ---------- Overlay ----------
    fun render() {
        stopRun()
        removeAll()
        for (b in Store.buttons.values) createViews(b)
        if (Store.buttons.isNotEmpty()) createCtl()
        refreshTouch()
    }

    fun refreshMode() {
        stopRun()
        refreshTouch()
    }

    private fun makeView(text: String, color: Int, alpha: Float): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(Color.WHITE)
        tv.gravity = Gravity.CENTER
        tv.textSize = (Store.size / 9f).coerceIn(10f, 26f)
        tv.alpha = alpha
        tv.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        return tv
    }

    private fun params(cx: Float, cy: Float, size: Int): WindowManager.LayoutParams {
        return WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (cx - size / 2f).toInt()
            y = (cy - size / 2f).toInt()
        }
    }

    private fun createViews(b: Btn) {
        val color = when (b.type) {
            "single" -> Color.parseColor("#E53935")
            "seq" -> Color.parseColor("#1E88E5")
            "swipe" -> Color.parseColor("#8E24AA")
            else -> Color.parseColor("#43A047")
        }
        val a = Store.alphaPct / 100f
        val v = makeView(b.label, color, a)
        wm.addView(v, params(b.x, b.y, Store.size))
        attachTouch(v, b, false)
        btnViews[b.id] = v

        if (b.type == "single" || b.type == "swipe") {
            val t = makeView(if (b.type == "swipe") ">" else "+", Color.parseColor("#FB8C00"), a * 0.7f)
            wm.addView(t, params(b.tx, b.ty, Store.size / 2))
            attachTouch(t, b, true)
            tgtViews[b.id] = t
        }
    }

    // Grey bubble: EDIT / PLAY / STOP. Tap = kaam, drag = jagah badlo
    private fun createCtl() {
        val size = Store.size * 3 / 4
        val v = makeView("PLAY", Color.parseColor("#616161"), 0.85f)
        v.textSize = 11f
        val dm = resources.displayMetrics
        val lp = params(0f, 0f, size)
        lp.x = if (Store.ctlX >= 0) Store.ctlX else dm.widthPixels - size - 20
        lp.y = if (Store.ctlY >= 0) Store.ctlY else 200
        wm.addView(v, lp)
        attachCtl(v)
        ctlView = v
    }

    private fun updateCtl() {
        ctlView?.text = if (runningId != -1) "STOP" else if (Store.edit) "PLAY" else "EDIT"
    }

    private fun attachCtl(v: TextView) {
        var dx = 0f
        var dy = 0f
        var sx = 0f
        var sy = 0f
        var moved = false
        v.setOnTouchListener { _, e ->
            val lp = v.layoutParams as WindowManager.LayoutParams
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX - lp.x
                    dy = e.rawY - lp.y
                    sx = e.rawX
                    sy = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) > 15 || abs(e.rawY - sy) > 15) moved = true
                    if (moved) {
                        lp.x = (e.rawX - dx).toInt()
                        lp.y = (e.rawY - dy).toInt()
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        Store.ctlX = lp.x
                        Store.ctlY = lp.y
                        Store.save(this)
                    } else if (runningId != -1) {
                        stopRun()
                    } else {
                        toggleEdit()
                    }
                }
            }
            true
        }
    }

    private fun toggleEdit() {
        Store.edit = !Store.edit
        stopRun()
        refreshTouch()
    }

    private fun attachTouch(v: View, b: Btn, isTarget: Boolean) {
        var dx = 0f
        var dy = 0f
        v.setOnTouchListener { _, e ->
            val lp = v.layoutParams as WindowManager.LayoutParams
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX - lp.x
                    dy = e.rawY - lp.y
                    if (!Store.edit && !isTarget) onPress(b)
                }
                MotionEvent.ACTION_MOVE -> if (Store.edit) {
                    lp.x = (e.rawX - dx).toInt()
                    lp.y = (e.rawY - dy).toInt()
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> {
                    if (Store.edit) endDrag(lp, b, isTarget)
                    else if (!isTarget) onRelease(false)
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (Store.edit) endDrag(lp, b, isTarget)
                    else if (!isTarget) onRelease(true)
                }
            }
            true
        }
    }

    private fun endDrag(lp: WindowManager.LayoutParams, b: Btn, isTarget: Boolean) {
        val cx = lp.x + lp.width / 2f
        val cy = lp.y + lp.height / 2f
        if (isTarget) {
            b.tx = cx
            b.ty = cy
        } else {
            b.x = cx
            b.y = cy
            if (b.type == "seq") {
                b.tx = cx
                b.ty = cy
            }
        }
        Store.save(this)
    }

    // ---------- Press / Release ----------
    private fun onPress(b: Btn) {
        pressAt = SystemClock.uptimeMillis()
        if (runningId != -1) {   // chal raha hai to ek tap se band
            stopRun()
            return
        }
        startRun(b)
    }

    private fun onRelease(cancelled: Boolean) {
        if (Store.mode != "hold") return
        if (runningId == -1) return
        if (cancelled && SystemClock.uptimeMillis() - pressAt < 1000) {
            // Android ne tap bhejte hi touch cancel kar diya: is phone par hold possible nahi
            Store.mode = "toggle"
            Store.save(this)
            Toast.makeText(
                this,
                "Is phone par hold possible nahi. Toggle mode ON: ek tap = start, dobara tap = stop",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        stopRun()
    }

    // Play mode: seq/swipe circles aur target dots touch-through ho jate hain
    private fun refreshTouch() {
        val vis = if (Store.hidden) View.GONE else View.VISIBLE
        for ((id, v) in btnViews) {
            val b = Store.buttons[id] ?: continue
            val through = !Store.edit && (b.type == "seq" || b.type == "swipe")
            val lp = v.layoutParams as WindowManager.LayoutParams
            lp.flags = baseFlags or (if (through) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0)
            wm.updateViewLayout(v, lp)
            v.visibility = vis
        }
        for ((_, v) in tgtViews) {
            val lp = v.layoutParams as WindowManager.LayoutParams
            lp.flags = baseFlags or (if (!Store.edit) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0)
            wm.updateViewLayout(v, lp)
            v.visibility = vis
        }
        updateCtl()
    }

    private fun removeAll() {
        for (v in btnViews.values) try { wm.removeView(v) } catch (e: Exception) { }
        for (v in tgtViews.values) try { wm.removeView(v) } catch (e: Exception) { }
        val c = ctlView
        if (c != null) {
            try { wm.removeView(c) } catch (e: Exception) { }
        }
        ctlView = null
        btnViews.clear()
        tgtViews.clear()
    }

    // ---------- Tap engine ----------
    private fun startRun(b: Btn) {
        when (b.type) {
            "single" -> runSingle(b)
            "main" -> runSequence(b.id)
        }
    }

    private fun stopRun() {
        runToken++
        runningId = -1
        handler.removeCallbacksAndMessages(null)
        updateCtl()
    }

    private fun finish(t: Int) {
        if (t == runToken) {
            runningId = -1
            updateCtl()
        }
    }

    private fun scheduleAutoStop(t: Int) {
        if (Store.autoStopSec > 0) {
            handler.postDelayed({ if (t == runToken) stopRun() }, Store.autoStopSec * 1000L)
        }
    }

    private fun stepDuration(b: Btn): Long {
        if (b.type == "swipe") return b.holdMs.toLong().coerceAtLeast(50L)
        if (b.holdMs > 0) return b.holdMs.toLong()
        return Store.tapMs.toLong()
    }

    private fun doStep(b: Btn) {
        if (b.type == "swipe") {
            swipe(jit(b.x), jit(b.y), jit(b.tx), jit(b.ty), stepDuration(b))
        } else {
            tap(jit(b.tx), jit(b.ty), stepDuration(b))
        }
    }

    private fun runSingle(b: Btn) {
        val t = ++runToken
        runningId = b.id
        updateCtl()
        val base = (1000L / b.cps.coerceIn(1, Store.MAX_CPS)).coerceAtLeast(Store.tapMs + 10L)
        scheduleAutoStop(t)
        val r = object : Runnable {
            override fun run() {
                if (t != runToken) return
                tap(jit(b.tx), jit(b.ty))
                handler.postDelayed(this, rdelay(base))
            }
        }
        handler.post(r)
    }

    private fun runSequence(mainId: Int) {
        val ids = Store.seq.toList()
        if (ids.isEmpty()) {
            Toast.makeText(this, "Pehle Sequence step buttons banao", Toast.LENGTH_SHORT).show()
            return
        }
        val t = ++runToken
        runningId = mainId
        updateCtl()
        scheduleAutoStop(t)
        var i = 0
        var rounds = 0
        val r = object : Runnable {
            override fun run() {
                if (t != runToken) return
                val b = Store.buttons[ids[i]]
                var wait = 100L
                if (b != null) {
                    doStep(b)
                    wait = stepDuration(b) + b.delayMs.coerceAtLeast(20)
                }
                i++
                if (i >= ids.size) {
                    i = 0
                    rounds++
                    if (!Store.loop && Store.repeat == 0) { finish(t); return }
                    if (Store.repeat > 0 && rounds >= Store.repeat) { finish(t); return }
                }
                handler.postDelayed(this, rdelay(wait))
            }
        }
        handler.post(r)
    }
}
